#ifndef THIS
#define THIS
#include "dnode.h"

void print(DNode *res);
void usage();
#endif
